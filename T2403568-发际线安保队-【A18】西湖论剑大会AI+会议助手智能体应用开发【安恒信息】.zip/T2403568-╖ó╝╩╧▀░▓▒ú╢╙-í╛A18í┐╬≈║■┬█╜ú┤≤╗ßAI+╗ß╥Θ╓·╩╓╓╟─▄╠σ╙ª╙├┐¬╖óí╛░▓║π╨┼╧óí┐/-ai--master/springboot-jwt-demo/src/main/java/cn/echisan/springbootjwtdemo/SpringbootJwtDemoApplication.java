package cn.echisan.springbootjwtdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJwtDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootJwtDemoApplication.class, args);
    }
}


