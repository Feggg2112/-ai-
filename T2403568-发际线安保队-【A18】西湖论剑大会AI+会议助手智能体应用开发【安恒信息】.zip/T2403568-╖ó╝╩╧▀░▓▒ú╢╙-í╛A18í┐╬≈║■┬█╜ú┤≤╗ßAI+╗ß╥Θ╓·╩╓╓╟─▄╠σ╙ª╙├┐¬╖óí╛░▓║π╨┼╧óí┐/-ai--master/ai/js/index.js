 // 登录按钮跳转
 document.getElementById('AIButton').addEventListener('click', function () {
    // 跳转到指定页面
    window.location.href = 'ai.html';
});
 // 登录按钮跳转
 document.getElementById('message_importButton').addEventListener('click', function () {
    // 跳转到指定页面
    window.location.href = 'message_import.html';
});
 // 登录按钮跳转
 document.getElementById('meeting_importButton').addEventListener('click', function () {
    // 跳转到指定页面
    window.location.href = 'meeting_import.html';
});
 // 登录按钮跳转
 document.getElementById('meeting_summaryButton').addEventListener('click', function () {
    // 跳转到指定页面
    window.location.href = 'meeting_index.html';
});